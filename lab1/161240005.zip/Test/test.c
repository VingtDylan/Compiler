/*int main()
{
   int i=1; 
   float y;
   return 0;
}*/
/*int main(){
  int i=1;
  int j=~i;
}*/

int main(){
  float a[10][2];
  int i;
  float x=e5
  int j=1;
  a[5,3]=5;
  if(a[1][2]==0) i=1 else i=0; 
}

